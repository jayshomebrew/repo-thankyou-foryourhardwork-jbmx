1. find your plugsin folder, ie:  /plugin.video.scrubsv2/resources/lib/sources/working
2. rename f123movies_com.py to f123movies_com.py.bak
3. copy this file into the plugins folder: /plugin.video.scrubsv2/resources/lib/sources/working

-test links in kodi.
